package com.example.notesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.notesapp.data.DatebaseHelper;
import com.example.notesapp.model.RecordNotes;

public class updateAndDelete extends AppCompatActivity {
    Button updateButton;
    Button deleteButton;
    EditText editText;
    RecordNotes selectedNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_and_delete);

        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);
        editText = findViewById(R.id.editNote);
        selectedNote = NotesList.selectedNote;
        DatebaseHelper db = new DatebaseHelper(updateAndDelete.this);

        updateButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent previousIntent = getIntent();

                int passedNoteID = previousIntent.getIntExtra(RecordNotes.NOTE_UPDATE, -1);
                selectedNote = RecordNotes.getNoteForID(passedNoteID);

                if (selectedNote != null)
                {
                    editText.setText(selectedNote.getNoteContent());
                    db.updateNote(selectedNote);
                }
                finish();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent previousIntent = getIntent();

                int passedNoteID = previousIntent.getIntExtra(RecordNotes.NOTE_UPDATE, -1);
                selectedNote = RecordNotes.getNoteForID(passedNoteID);

                if (selectedNote != null)
                {
                    db.deleteNote(selectedNote);
                }
                finish();
            }
        });
    }

}